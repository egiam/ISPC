# Apuntes
Apuntes Teóricos y Prácticos del Programa


En el canal de youtube podrás encontrar expicaciones para algunos temas, además de los exámenes para prácticar. [Ver](https://www.youtube.com/channel/UCMTcqi9zozNFxIoTzJI6EgA/playlists?view_as=subscriber).
